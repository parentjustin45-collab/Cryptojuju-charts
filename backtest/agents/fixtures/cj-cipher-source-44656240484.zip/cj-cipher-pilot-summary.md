# CJ Cipher — Première étude WaveTrend WT1/WT2 sur Bitunix

**CIPHER_3_MARKETS_FIRST_PILOT_COMPLETE** (3 / 3 marchés).

Port fidèle à la formule fournie en Pine Script v6, sans divergences ni changements de paramètres : ESA EMA10, déviation EMA10, CI normalisé /0,015, WT1 EMA21, WT2 SMA4. Seuls les CROISEMENTS WT1/WT2 à clôture confirmée forment des événements. Les niveaux 60/53 et −60/−53 sont VISUELS, aucun filtre implicite.

Trois bras pré-déclarés : Cipher seul (croisements); Vector V1.1 seul (signaux originaux); Vector filtré par le signe WT1−WT2 à la même clôture (refus opposé = FLAT). Aucune sélection ni optimisation de paramètres sur les résultats.

Les trois bras partagent le moteur de portefeuilles RÉVERSAL-ONLY de la phase fixed-holdout, avec 70 % entraînement / 30 % historique réexaminé, même frais/contrôles. Cette première recherche NE teste PAS de stop ATR/objectif, donc NE DOIT PAS être comparée numériquement aux résultats du moteur ATR Vector précédent.

Sources strictes : Futures LAST_PRICE Bitunix public, 960 chandelles 1H terminées par marché, double lecture prouvée, contrôle de continuité et SHA. Parité exacte Pine/TradingView **non vérifiée** : l’absence de simulation intrabar est volontaire (confirmClose=true par défaut).

| Marché | Source validée | Cipher LONG | Cipher SHORT | Vector événements | Vector admis par WT |
|---|---|---:|---:|---:|---:|
| BTCUSDT | RESEARCH_CAUSAL_FIRST_PILOT_READY | 73 | 73 | 56 | 33 |
| HYPEUSDT | RESEARCH_CAUSAL_FIRST_PILOT_READY | 74 | 74 | 67 | 33 |
| 1000PEPEUSDT | RESEARCH_CAUSAL_FIRST_PILOT_READY | 68 | 68 | 43 | 25 |

## Portion historique 30 % déjà observée — résultats uniquement exploratoires
| Marché | Frais | Mode | Trades | Retour hypothétique | Drawdown | Suffisance |
|---|---|---|---:|---:|---:|---|
| BTCUSDT | base | cj_cipher_wt_v1 | 39 | -7.17 % | 14.79 % | DESCRIPTIVE_ONLY |
| BTCUSDT | base | vector_v11 | 17 | -6.42 % | 12.12 % | INSUFFICIENT_TRADES |
| BTCUSDT | base | vector_v11_cipher_agreement | 8 | 3.36 % | 5.75 % | INSUFFICIENT_TRADES |
| BTCUSDT | stress | cj_cipher_wt_v1 | 39 | -19.94 % | 21.95 % | DESCRIPTIVE_ONLY |
| BTCUSDT | stress | vector_v11 | 17 | -12.24 % | 16.17 % | INSUFFICIENT_TRADES |
| BTCUSDT | stress | vector_v11_cipher_agreement | 8 | 0.30 % | 6.68 % | INSUFFICIENT_TRADES |
| HYPEUSDT | base | cj_cipher_wt_v1 | 43 | -2.72 % | 20.03 % | DESCRIPTIVE_ONLY |
| HYPEUSDT | base | vector_v11 | 23 | -12.60 % | 24.46 % | DESCRIPTIVE_ONLY |
| HYPEUSDT | base | vector_v11_cipher_agreement | 11 | -12.23 % | 14.38 % | INSUFFICIENT_TRADES |
| HYPEUSDT | stress | cj_cipher_wt_v1 | 43 | -17.37 % | 26.22 % | DESCRIPTIVE_ONLY |
| HYPEUSDT | stress | vector_v11 | 23 | -19.92 % | 27.87 % | DESCRIPTIVE_ONLY |
| HYPEUSDT | stress | vector_v11_cipher_agreement | 11 | -15.83 % | 16.35 % | INSUFFICIENT_TRADES |
| 1000PEPEUSDT | base | cj_cipher_wt_v1 | 39 | -26.05 % | 34.22 % | DESCRIPTIVE_ONLY |
| 1000PEPEUSDT | base | vector_v11 | 14 | 30.35 % | 12.63 % | INSUFFICIENT_TRADES |
| 1000PEPEUSDT | base | vector_v11_cipher_agreement | 8 | -5.38 % | 12.35 % | INSUFFICIENT_TRADES |
| 1000PEPEUSDT | stress | cj_cipher_wt_v1 | 39 | -36.27 % | 39.74 % | DESCRIPTIVE_ONLY |
| 1000PEPEUSDT | stress | vector_v11 | 14 | 23.79 % | 13.94 % | INSUFFICIENT_TRADES |
| 1000PEPEUSDT | stress | vector_v11_cipher_agreement | 8 | -8.26 % | 14.35 % | INSUFFICIENT_TRADES |

Base : 0,06 % frais + 0,05 % slippage par côté; stress : 0,10 % + 0,20 %. 1000 $ fictifs par phase, allocation max 100 %; aucune taille de lot ou funding réels. Les signaux de confirmation n’impliquent PAS des probabilités de réussite.

Ne pas promouvoir un gagnant sur une période déjà inspectée; futurs travaux : mesurer strictement la parité WT1/WT2 TradingView, passer à une gestion ATR identique, étudier ensuite SPEED et Frank Test sur des périodes prospectives distinctes.

Aucun ordre, aucun changement main/site public, aucune promotion automatique.
